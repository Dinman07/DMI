
public class Triangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("        T          ");
		System.out.println("       TTT         ");
		System.out.println("      TTTTT        ");
		System.out.println("     TTTTTTT       ");
		System.out.println("    TTTTTTTTT      ");
		System.out.println("   TTTTTTTTTTT     ");
		System.out.println("  TTTTTTTTTTTTT    ");

	}

}
