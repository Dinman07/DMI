
public class MovieQuoteInfo {

	public static void main(String[] args) {

		System.out.println("If you're not first, you're last.");
		System.out.println("Talladega Nights");
		System.out.println("Ricky Bobby");
		System.out.println("2006");
		
	}

}
