
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("A 40 HP Johnson on a flat bottom metal boat");
		System.out.println("Coke cans and BB guns, barbed wire and old fence posts");
		System.out.println("8-point bucks in Autumn and freshly cut corn fields");
		System.out.println("One arm out the window and one hand on the wheel");
		System.out.println("Some things just go better together and probably always will");

	}

}
